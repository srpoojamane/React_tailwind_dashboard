import React, { useState } from 'react';
import { useSelector, useDispatch } from "react-redux";
import { addExpense, removeExpense } from "../redux/budgetSlice";
import { RootState, AppDispatch } from "../store/store";
import ReactApexChart from 'react-apexcharts';

export default function Budget() {
  const { totalBudget, expenses } = useSelector((state: RootState) => state.budget);
  const dispatch: AppDispatch = useDispatch();
  const [googleAds, setGoogleAds] = useState<{ name: string; amount: string }>({ name: "Google Ads", amount: "" });
  const [facebookAds, setFacebookAds] = useState<{ name: string; amount: string }>({ name: "Facebook Ads", amount: "" });
  const [linkedinAds, setLinkedinAds] = useState<{ name: string; amount: string }>({ name: "LinkedIn Ads", amount: "" });

  // Handle add expense
  const handleAddExpense = (platform: string, amount: string) => {
    if (amount) {
      dispatch(addExpense({ id: Date.now(), name: platform, amount: Number(amount) }));
    }
  };

  // Calculate total spent for each platform
  const googleAdsSpent = expenses.filter(exp => exp.name === 'Google Ads').reduce((sum, exp) => sum + exp.amount, 0);
  const facebookAdsSpent = expenses.filter(exp => exp.name === 'Facebook Ads').reduce((sum, exp) => sum + exp.amount, 0);
  const linkedinAdsSpent = expenses.filter(exp => exp.name === 'LinkedIn Ads').reduce((sum, exp) => sum + exp.amount, 0);

  // Define chart options for Google Ads, Facebook Ads, LinkedIn Ads
  const generateChartOptions = (spent: number, totalBudget: number) => ({
    chart: {
      type: 'radialBar',
      height: 350,
      sparkline: {
        enabled: true,
      },
    },
    series: [(spent / totalBudget) * 100], // Represent the percentage of spent budget
    plotOptions: {
      radialBar: {
        startAngle: -90,
        endAngle: 90,
        hollow: {
          size: '50%',
        },
        dataLabels: {
          name: {
            show: false,
          },
          value: {
            fontSize: '30px',
            fontWeight: 'bold',
            color: '#333',
            offsetY: 20,
          },
        },
      },
    },
    colors: ['#FF4560'], // Red color for visualization
    labels: ['Total Spend'],
    title: {
      text: 'Ad Spend',
      align: 'center',
      style: {
        fontSize: '16px',
        fontWeight: 'bold',
        color: '#333',
      }
    },
  });

  return (
    <div className="p-6 w-full max-w-lg-12 mx-auto mt-6 bg-white shadow-lg rounded-lg">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Ad Spend Tracker</h2>

      {/* Google Ads Budget Inputs */}
      <div className="flex gap-3 mb-4 h-10">
        <input
          type="number"
          placeholder="Google Ads Amount"
          value={googleAds.amount}
          onChange={(e) => setGoogleAds({ ...googleAds, amount: e.target.value })}
          className="border p-3 rounded-lg w-full focus:ring-2 focus:ring-blue-500"
        />
        <button
          onClick={() => handleAddExpense(googleAds.name, googleAds.amount)}
          className="w-full px-1 py-1 bg-blue-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          Add Google Ads
        </button>
      </div>

      {/* Facebook Ads Budget Inputs */}
      <div className="flex gap-3 mb-4 h-10">
        <input
          type="number"
          placeholder="Facebook Ads Amount"
          value={facebookAds.amount}
          onChange={(e) => setFacebookAds({ ...facebookAds, amount: e.target.value })}
          className="border p-3 rounded-lg w-full focus:ring-2 focus:ring-blue-500"
        />
        <button
          onClick={() => handleAddExpense(facebookAds.name, facebookAds.amount)}
          className="w-full px-1 py-1 bg-blue-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          Add Facebook Ads
        </button>
      </div>

      {/* LinkedIn Ads Budget Inputs */}
      <div className="flex gap-3 mb-4 h-10">
        <input
          type="number"
          placeholder="LinkedIn Ads Amount"
          value={linkedinAds.amount}
          onChange={(e) => setLinkedinAds({ ...linkedinAds, amount: e.target.value })}
          className="border p-3 rounded-lg w-full focus:ring-2 focus:ring-blue-500"
        />
        <button
          onClick={() => handleAddExpense(linkedinAds.name, linkedinAds.amount)}
          className="w-full px-1 py-1 bg-blue-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          Add LinkedIn Ads
        </button>
      </div>

      {/* Render Radial Bar Chart for Google Ads */}
      <div className="grid grid-cols-3 gap-4 text-center"> <div className="mt-6">
        <h3 className="text-xl font-semibold text-gray-800">Google Ads Spend</h3>
        <ReactApexChart
          options={generateChartOptions(googleAdsSpent, totalBudget)}
          series={[googleAdsSpent]} 
          type="radialBar"
          height={350}
        />
      </div>

      {/* Render Radial Bar Chart for Facebook Ads */}
      
      <div className="mt-6">
        <h3 className="text-xl font-semibold text-gray-800">Facebook Ads Spend</h3>
        <ReactApexChart
          options={generateChartOptions(facebookAdsSpent, totalBudget)}
          series={[facebookAdsSpent]} 
          type="radialBar"
          height={350}
        />
      </div>

      {/* Render Radial Bar Chart for LinkedIn Ads */}
      <div className="mt-6">
        <h3 className="text-xl font-semibold text-gray-800">LinkedIn Ads Spend</h3>
        <ReactApexChart
          options={generateChartOptions(linkedinAdsSpent, totalBudget)}
          series={[linkedinAdsSpent]} 
          type="radialBar"
          height={350}
        />
      </div>
     </div>
      {/* List of expenses */}
      <ul className="mt-4 divide-y divide-gray-200">
        {expenses.map((exp) => (
          <li key={exp.id} className="flex justify-between items-center py-3">
            <span className="text-gray-800 font-medium">{exp.name}: <span className="text-gray-900 font-semibold">${exp.amount}</span></span>
            <button
              onClick={() => dispatch(removeExpense(exp.id))}
              className="text-sm px-3 py-1 bg-red-500 text-white rounded-lg hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500"
            >
              X
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
