import React, { useEffect, useState } from "react";
import { BsFillTrashFill, BsFillPencilFill } from "react-icons/bs";

const rowsPerPage = 6; // Customize rows per page

export const Table = () => {
  const [data, setData] = useState<any>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [editMode, setEditMode] = useState(false);
  const [editingBond, setEditingBond] = useState<string | null>(null);
  const [editValue, setEditValue] = useState<{ [key: string]: any }>({});

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("/data.json"); // Fetch from public folder
        const jsonData = await response.json();
        setData(jsonData);
      } catch (error) {
        console.error("Error loading data.json:", error);
      }
    };

    fetchData();
  }, []);

  if (!data) return <div className="text-center py-10">Loading...</div>;

  const bonds = Object.keys(data);
  const fields = Object.keys(data[bonds[0]]).filter(
    (key) => !key.startsWith("delta_")
  );

  // Pagination Logic
  const totalPages = Math.ceil(bonds.length / rowsPerPage);
  const startIdx = (currentPage - 1) * rowsPerPage;
  const selectedRows = bonds.slice(startIdx, startIdx + rowsPerPage);

  // **Delete Row Function**
  const deleteRow = (bond: string) => {
    const updatedData = { ...data };
    delete updatedData[bond]; // Remove bond from object
    setData(updatedData);
  };

  // **Edit Row Functions**
  const startEditing = (bond: string) => {
    setEditingBond(bond);
    setEditMode(true);
    setEditValue({ ...data[bond] });
  };

  const handleEditChange = (field: string, value: any) => {
    setEditValue((prev) => ({ ...prev, [field]: value }));
  };

  const saveEdit = () => {
    if (editingBond) {
      setData((prevData: any) => ({
        ...prevData,
        [editingBond]: editValue,
      }));
      setEditMode(false);
      setEditingBond(null);
    }
  };

  return (
    <div className="max-w-full overflow-x-auto">
      {/* Table */}
      <table className="w-full border-collapse border bg-stone-300 text-black">
        <thead>
          <tr className="bg-stone-400 text-white text-left">
            <th className="py-3 px-4 border">Bond</th>
            {fields.map((field) => (
              <th key={field} className="py-3 px-4 border capitalize">{field}</th>
            ))}
            <th className="py-3 px-4 border">Actions</th>
          </tr>
        </thead>
        <tbody>
          {selectedRows.map((bond, idx) => (
            <tr key={idx} className="text-center">
              <td className="border py-3 px-4 font-medium">{bond}</td>

              {fields.map((field) => (
                <td key={field} className="border py-3 px-4">
                  {editMode && editingBond === bond ? (
                    <input
                      type="text"
                      value={editValue[field]}
                      onChange={(e) => handleEditChange(field, e.target.value)}
                      className="border p-1 w-full text-center"
                    />
                  ) : (
                    data[bond][field]
                  )}
                </td>
              ))}

              <td className="border py-3 px-4">
                <div className="flex justify-center gap-4">
                  {editMode && editingBond === bond ? (
                    <button onClick={saveEdit} className="text-green-500 font-bold">
                      ✅ Save
                    </button>
                  ) : (
                    <>
                      <BsFillTrashFill
                        className="cursor-pointer text-red-500 hover:text-red-700"
                        onClick={() => deleteRow(bond)}
                      />
                      <BsFillPencilFill
                        className="cursor-pointer text-blue-500 hover:text-blue-700"
                        onClick={() => startEditing(bond)}
                      />
                    </>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pagination Controls */}
      <div className="flex justify-between items-center mt-4">
        <button
          className={`px-4 py-2 rounded bg-blue-300 text-white ${
            currentPage === 1 ? "opacity-50 cursor-not-allowed" : "hover:bg-blue-400"
          }`}
          onClick={() => setCurrentPage(currentPage - 1)}
          disabled={currentPage === 1}
        >
          Previous
        </button>

        <span className="text-sm font-medium">
          Page {currentPage} of {totalPages}
        </span>

        <button
          className={`px-4 py-2 rounded bg-blue-300  text-white ${
            currentPage === totalPages ? "opacity-50 cursor-not-allowed" : "hover:bg-blue-400"
          }`}
          onClick={() => setCurrentPage(currentPage + 1)}
          disabled={currentPage === totalPages}
        >
          Next
        </button>
      </div>
    </div>
  );
};
