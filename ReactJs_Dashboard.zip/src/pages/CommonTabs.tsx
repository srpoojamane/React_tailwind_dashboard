import { useState } from "react";
import * as LucideIcons from "lucide-react";

import { Table } from '../components/TableSettings';
const CommonTabs = ( {tabs}) => {
  const [activeTab, setActiveTab] = useState("Home");

// end component


  // Find the current active tab's icon and component
  const activeTabData = tabs.find((tab) => tab.name === activeTab) || {};
  const IconComponent = LucideIcons[activeTabData.icon] || LucideIcons.Circle;
  const ActiveComponent = activeTabData.component || <p>No Content Available</p>;

  return (
    <div className="w-full flex flex-col items-center p-2 ">
      {/* Tab Navigation */}
      <div className="dark:bg-boxdark dark:drop-shadow-none w-full flex space-x-4 justify-between bg-gray-200 p-2 rounded-lg shadow-md">
        {tabs.map(({ name, icon }) => {
          const TabIcon = LucideIcons[icon] || LucideIcons.Circle; // Fallback icon

          return (
            <button
              key={name}
              onClick={() => setActiveTab(name)}
              className={`dark:bg-boxdark dark:drop-shadow-none flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 
              ${activeTab === name ? "bg-blue-500 text-white" : "bg-white text-gray-700 hover:bg-gray-300"}`}
            >
              <TabIcon className="w-5 h-5 " />
              <span>{name}</span>
            </button>
          );
        })}
      </div>

      {/* Active Tab Content */}
      <div className="mt-4 p-4 border rounded-lg shadow-md w-full text-center ">
        <IconComponent className="w-10 h-10 mx-auto text-blue-500" />
        <p className="text-lg font-semibold mt-2">Current Tab: {activeTab}</p>
        <div className="mt-4">{ActiveComponent}</div>
      </div>
    </div>
  );
};

export default CommonTabs;