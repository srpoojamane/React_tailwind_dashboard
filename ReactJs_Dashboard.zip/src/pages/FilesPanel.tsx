import { Search, Upload, FileText, Folder, Pencil } from "lucide-react";

const FilesPanel = () => {
  const files = [
    { id: 1, name: "Client - Mayfair", owner: "Matt Smith", type: "folder" },
    { id: 2, name: "Client - Mayfair", owner: "Matt Smith", type: "folder" },
    { id: 3, name: "Client - Mayfair", owner: "Matt Smith", type: "folder" },
    { id: 4, name: "Client - Mayfair", owner: "Matt Smith", type: "folder" },
    { id: 5, name: "Proposal.pdf", owner: "Sarah Johnson", type: "file" },
    { id: 6, name: "Invoice.xlsx", owner: "John Doe", type: "file" },
    { id: 7, name: "Client - Mayfair", owner: "Matt Smith", type: "folder" },
    { id: 8, name: "Proposal.pdf", owner: "Sarah Johnson", type: "file" },
    { id: 9, name: "Invoice.xlsx", owner: "John Doe", type: "file" },
  ];

  return (
    <div className="bg-white dark:bg-gray-900 p-4 rounded-lg shadow-md w-full">
      {/* Header Section */}
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Files</h2>
        <div className="flex items-center space-x-4">
          <span className="text-gray-600 dark:text-gray-300 text-sm cursor-pointer">Open</span>
          <Pencil className="w-4 h-4 text-gray-500 cursor-pointer" />
        </div>
      </div>

      {/* Tabs & Profile */}
      <div className="flex items-center justify-between mt-2">
        {/* Internal Tab */}
        <div className="flex items-center space-x-2 border-b-2 border-blue-500 pb-1 cursor-pointer">
          <Folder className="text-blue-500 w-5 h-5" />
          <span className="text-blue-500 font-medium">Internal</span>
        </div>

        {/* Profile */}
        <div className="flex items-center space-x-2">
          <div className="relative">
            <img
              src="https://randomuser.me/api/portraits/women/44.jpg"
              alt="User"
              className="w-8 h-8 rounded-full"
            />
            <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white"></span>
          </div>
          <span className="font-medium text-gray-900 dark:text-white">Xamtac</span>
        </div>
      </div>

      {/* Search & Upload */}
      <div className="flex items-center justify-between bg-gray-100 dark:bg-gray-800 px-3 py-2 rounded-lg mt-4">
        <div className="flex items-center w-full">
          <Search className="w-5 h-5 text-gray-500" />
          <input
            type="text"
            placeholder="Search"
            className="bg-transparent ml-2 outline-none text-gray-700 dark:text-gray-300 w-full"
          />
        </div>
        <button className="bg-gray-200 dark:bg-gray-700 p-2 rounded-lg">
          <Upload className="w-5 h-5 text-gray-500" />
        </button>
      </div>

      {/* File List */}
      <div className="mt-4">
        <div className="flex justify-between px-4 py-2 bg-gray-100 dark:bg-gray-800 rounded-t-lg text-sm font-medium text-gray-600 dark:text-gray-300">
          <span>Name</span>
          <span>Owner</span>
        </div>
        
        {files.map((file) => (
          <div key={file.id} className="flex justify-between items-center px-4 py-2 border-b text-gray-800 dark:text-gray-200">
            <div className="flex items-center space-x-3">
              <input type="checkbox" className="form-checkbox w-4 h-4 text-blue-600" />
              {file.type === "folder" ? (
                <Folder className="text-yellow-500 w-5 h-5" />
              ) : (
                <FileText className="text-gray-500 w-5 h-5" />
              )}
              <span>{file.name}</span>
            </div>
            <span className="text-gray-500 text-sm">{file.owner}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FilesPanel;
