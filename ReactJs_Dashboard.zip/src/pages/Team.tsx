import { useState } from "react";
import ChatCard from "../components/Chat/ChatCard";
import FilesPanel from "./FilesPanel";
const Team = ({ members }) => {
    
  return (<>
    <div className="bg-white dark:bg-gray-800 p-4 rounded-xl shadow-md w-full">
      <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Our Team</h2>
      
     <div className="grid grid-cols-1 gap-4 md:grid-cols-2 md:gap-6 xl:grid-cols-4 2xl:gap-7.5">
        {members.map(({ id, name, role, avatar }) => (
          <div key={id} className="flex items-center space-x-4 p-3 border rounded-lg shadow-sm bg-gray-50 dark:bg-gray-700">
            <img
              src={avatar}
              alt={name}
              className="w-12 h-12 rounded-full object-cover"
            />
            <div>
              <p className="text-md font-medium text-gray-900 dark:text-white">{name}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">{role}</p>
            </div>
          </div>
        ))}
      </div>
    </div>

    <div className="w-full flex flex-row mt-4 gap-4">
  <div className="basis-1/2">  <ChatCard /></div>
  <div className="basis-1/2"> <FilesPanel/></div>
</div>
    </>
  );
};

export default Team;
