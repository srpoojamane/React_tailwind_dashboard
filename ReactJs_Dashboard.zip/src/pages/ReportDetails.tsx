import { Package } from 'lucide-react';
import Breadcrumb from '../components/Breadcrumbs/Breadcrumb';
import Brands from '../components/Report/Brands';
import Packges from '../components/Report/Packages';
import Products from '../components/Report/Products';
import CommonTabs from './CommonTabs';


// Define a type for report details props
interface ReportDetailsProps {
  title: string;
  date: string;
  author: string;
  summary: string;
  bgColor: string;
}

// Reusable Report Details Component
const ReportDetailsCard: React.FC<ReportDetailsProps> = ({ title, date, author, summary, bgColor }) => {
  return (
    <div className={`p-4 rounded-2xl shadow-md text-white ${bgColor}`}>
      <h2 className="text-xl font-semibold">{title}</h2>
      <p className="text-sm opacity-80">Date: {date}</p>
      <p className="text-sm opacity-80">Author: {author}</p>
      <p className="mt-2 text-sm">Summary: {summary}</p>
    </div>
  );
};

const Tables = () => {
  const tabs = [
    { name: "Q1 Financial", icon: "Home", component:    <ReportDetailsCard title="Q1 Financial Report" date="2024-04-01" author="John Doe" summary="Analysis of quarterly earnings and expenses." bgColor="bg-blue-500" />
    },
    { name: "Market Research", icon: "Users", component:   <ReportDetailsCard title="Market Research" date="2024-03-15" author="Jane Smith" summary="Insights into consumer behavior trends." bgColor="bg-green-500" />
    },
    { name: "Employee", icon: "Database", component:   <ReportDetailsCard title="Employee Satisfaction" date="2024-02-28" author="Alex Johnson" summary="Survey results and improvement plans." bgColor="bg-purple-500" />
    },
    { name: "Tech Innovations", icon: "BookOpen", component:   <ReportDetailsCard title="Tech Innovations" date="2024-01-20" author="Chris Lee" summary="Overview of recent advancements in AI." bgColor="bg-yellow-500" />
    },
    { name: "Sales", icon: "ClipboardList", component:  <ReportDetailsCard title="Sales Performance" date="2024-04-05" author="Sarah Kim" summary="Detailed breakdown of regional sales." bgColor="bg-red-500" />
    },
    { name: "Annual Growth", icon: "Upload", component:   <ReportDetailsCard title="Annual Growth" date="2023-12-31" author="Michael Brown" summary="Company performance review and projections." bgColor="bg-gray-500" />
    },
  ];
  return (
    <>
    <CommonTabs tabs={tabs}/>
      <Breadcrumb pageName="Report Details" />

      <div className="flex flex-col gap-10">
        <Brands />
        <Packges />
        <Products />
      </div>
    </>
  );
};

export default Tables;
