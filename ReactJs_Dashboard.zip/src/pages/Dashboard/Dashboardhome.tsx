import React from 'react';
import CardDataStats from '../../components/CardDataStats';
import ChartOne from '../../components/Charts/ChartOne';
import ChartThree from '../../components/Charts/ChartThree';
import ChartTwo from '../../components/Charts/ChartTwo';
import ChatCard from '../../components/Chat/ChatCard';
import MapOne from '../../components/Maps/MapOne';
import TableOne from '../../components/Report/Brands';
import Budget from '../../components/Budget';
import BudgetTracker from '../../components/BudgetTracker';
import AdBreakdown from '../Budgets/AdBreakDown';
import SocialMediaConversion from '../../components/SocialMediaConversion';
import Demographics from '../Budgets/Demographics';
import Tabs from '../../Tabs';
import { ArrowUp, ArrowDown } from "lucide-react";

const Dashboardhome: React.FC = () => {
  return (
    <>
      <Tabs/>
 
      {/* budgets */}
      <div className="flex flex-row">
  {/* <div className="basis-1/1"><Budget/></div> */}
  </div>
  {/* <div className="flex flex-row">
  <div className="basis-1/1"><BudgetTracker/></div>
</div>

<div className="w-full flex flex-row">
  <div className="basis-1/2"><AdBreakdown/></div>
  <div className="basis-1/2"><SocialMediaConversion/></div>
</div> */}
{/* <div className="flex flex-row"> <div className="w-full"><Demographics/></div></div>
  */}
      <div className="mt-4 grid grid-cols-12 gap-4 md:mt-6 md:gap-6 2xl:mt-7.5 2xl:gap-7.5">
        <ChartOne />
        <ChartTwo />
        <ChartThree />
        <MapOne />
        <div className="col-span-12 xl:col-span-8">
          <TableOne />
        </div>
        <ChatCard />
      </div>
    </>
  );
};

export default Dashboardhome;
