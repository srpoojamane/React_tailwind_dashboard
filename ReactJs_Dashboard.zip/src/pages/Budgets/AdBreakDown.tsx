import React from "react";
import ReactApexChart from "react-apexcharts";
import CommonTabs from "../CommonTabs";

// Define a type for ad performance props
interface AdPerformanceProps {
  title: string;
  impressions: string;
  clicks: string;
  conversions: string;
  bgColor: string;
}

// Reusable Ad Performance Component
const AdPerformanceCard: React.FC<AdPerformanceProps> = ({ title, impressions, clicks, conversions, bgColor }) => {
  return (
    <div className={`p-4 rounded-2xl shadow-md text-white ${bgColor}`}>
      <h2 className="text-xl font-semibold">{title}</h2>
      <p className="text-sm opacity-80">Impressions: {impressions}</p>
      <p className="text-sm opacity-80">Clicks: {clicks}</p>
      <p className="mt-2 text-sm">Conversions: {conversions}</p>
    </div>
  );
};

export default function AdBreakdown() {
  const tabs = [
    { name: "Google Ads", icon: "Home", component:    <AdPerformanceCard title="Google Ads" impressions="100K" clicks="5K" conversions="500" bgColor="bg-blue-500" />
    },
    { name: "Facebook Ads", icon: "Users", component:   <AdPerformanceCard title="Facebook Ads" impressions="80K" clicks="4K" conversions="400" bgColor="bg-green-500" />
    },
    { name: "Instagram Ads", icon: "Database", component: <AdPerformanceCard title="Instagram Ads" impressions="70K" clicks="3.5K" conversions="350" bgColor="bg-purple-500" />
    },
    { name: "Twitter", icon: "BookOpen", component:   <AdPerformanceCard title="Twitter Ads" impressions="50K" clicks="2K" conversions="200" bgColor="bg-yellow-500" />
    },
    { name: "LinkedIn", icon: "ClipboardList", component:   <AdPerformanceCard title="LinkedIn Ads" impressions="40K" clicks="1.5K" conversions="150" bgColor="bg-red-500" />
    },
    { name: "YouTube Ads", icon: "Upload", component:   <AdPerformanceCard title="YouTube Ads" impressions="90K" clicks="4.5K" conversions="450" bgColor="bg-gray-500" />
    },
  ];
  // Define data for the ring graph
  const chartData = {
    series: [40, 35, 25], // Sample data for Clicks, Cost, Conversions
    options: {
      chart: {
        type: "donut",
      },
      labels: ["Clicks", "Cost", "Conversions"],
      colors: ["#1E88E5", "#F44336", "#43A047"], // Blue, Red, Green
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 300,
            },
            legend: {
              position: "bottom",
            },
          },
        },
      ],
      legend: {
        position: "bottom",
      },
    },
  };

  return (<>
  <CommonTabs tabs={tabs}/>
    <div className="max-w-3xl mx-auto p-6 bg-white shadow-lg rounded-lg mt-10">
      <h2 className="text-2xl font-bold text-gray-800 text-center mb-4">
        Ad Performance Breakdown
      </h2>

      {/* Ring Graph */}
      <div className="flex justify-center">
        <ReactApexChart
          options={chartData.options}
          series={chartData.series}
          type="donut"
          height={350}
        />
      </div>

      {/* Device Breakdown */}
      <div className="mt-6">
        <h3 className="text-xl font-semibold text-gray-800 text-center mb-3">
          Device Breakdown
        </h3>
        <div className="grid grid-cols-3 gap-4 text-center">
          {/* Mobile */}
          <div className="bg-blue-100 p-4 rounded-lg shadow">
            <p className="text-lg font-medium text-gray-700">📱 Mobile</p>
            <p className="text-xl font-bold text-blue-500">50%</p>
          </div>

          {/* Laptop */}
          <div className="bg-red-100 p-4 rounded-lg shadow">
            <p className="text-lg font-medium text-gray-700">💻 Laptop</p>
            <p className="text-xl font-bold text-red-500">30%</p>
          </div>

          {/* Tablets */}
          <div className="bg-green-100 p-4 rounded-lg shadow">
            <p className="text-lg font-medium text-gray-700">📟 Tablet</p>
            <p className="text-xl font-bold text-green-500">20%</p>
          </div>
        </div>
      </div>
    </div>
    </>
  );
}
