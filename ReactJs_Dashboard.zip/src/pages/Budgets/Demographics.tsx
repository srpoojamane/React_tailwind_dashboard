import React from "react";
import ReactApexChart from "react-apexcharts";
import CommonTabs from "../CommonTabs";
// Define a type for demographic analytics props
interface DemographicAnalyticsProps {
  title: string;
  ageGroup: string;
  gender: string;
  location: string;
  bgColor: string;
}

// Reusable Demographic Analytics Component
const DemographicAnalyticsCard: React.FC<DemographicAnalyticsProps> = ({ title, ageGroup, gender, location, bgColor }) => {
  return (
    <div className={`p-4 rounded-2xl shadow-md text-white ${bgColor}`}>
      <h2 className="text-xl font-semibold">{title}</h2>
      <p className="text-sm opacity-80">Age Group: {ageGroup}</p>
      <p className="text-sm opacity-80">Gender: {gender}</p>
      <p className="mt-2 text-sm">Location: {location}</p>
    </div>
  );
};
export default function Demographics() {
  const tabs = [
    { name: "Young Aulds", icon: "Home", component:   <DemographicAnalyticsCard title="Young Adults" ageGroup="18-24" gender="Mixed" location="USA" bgColor="bg-blue-500" />
    },
    { name: "Team", icon: "Users", component:   <DemographicAnalyticsCard title="Middle-Aged" ageGroup="25-44" gender="Mixed" location="Europe" bgColor="bg-green-500" />
    },
    { name: "Senior Citizens", icon: "Database", component:  <DemographicAnalyticsCard title="Senior Citizens" ageGroup="45+" gender="Mixed" location="Asia" bgColor="bg-purple-500" />
    },
    { name: "Mixed", icon: "BookOpen", component:  <DemographicAnalyticsCard title="Teenagers" ageGroup="13-17" gender="Mixed" location="North America" bgColor="bg-yellow-500" />
    },
    { name: "Women Demo", icon: "ClipboardList", component:  <DemographicAnalyticsCard title="Women Demographics" ageGroup="25-40" gender="Female" location="Global" bgColor="bg-red-500" /> },
    { name: "Men Demo", icon: "Upload", component:    <DemographicAnalyticsCard title="Men Demographics" ageGroup="30-50" gender="Male" location="South America" bgColor="bg-gray-500" />
    },
  ];
  // Pie Chart Data (Gender Distribution)
  const pieChartData = {
    series: [45, 40, 15], // Male, Female, Undefined
    options: {
      chart: { type: "pie" },
      labels: ["Male", "Female", "Undefined"],
      colors: ["#1E88E5", "#E91E63", "#9E9E9E"], // Blue, Pink, Gray
      legend: { position: "bottom" },
    },
  };

  // Vertical Bar Chart Data (Age Group Distribution)
  const barChartData = {
    series: [
      {
        name: "Users",
        data: [35, 50, 30, 20], // Example age group data
      },
    ],
    options: {
      chart: { type: "bar" },
      xaxis: { categories: ["18-24", "25-34", "35-44", "45+"] },
      colors: ["#4CAF50"], // Green
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: "50%",
          borderRadius: 5,
        },
      },
    },
  };

  return (<>
  <CommonTabs tabs={tabs}/>
      <div className="max-w-4xl mx-auto p-6 bg-white shadow-lg rounded-lg mt-10">
      <h2 className="text-2xl font-bold text-gray-800 text-center mb-4">
        Demographic Analytics
      </h2>

      <div className="grid grid-cols-2 gap-6">
        {/* Pie Chart (Gender Breakdown) */}
        <div className="bg-gray-100 p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-700 text-center mb-3">
            Gender Distribution
          </h3>
          <ReactApexChart
            options={pieChartData.options}
            series={pieChartData.series}
            type="pie"
            height={300}
          />
        </div>

        {/* Vertical Bar Chart (Age Breakdown) */}
        <div className="bg-gray-100 p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-700 text-center mb-3">
            Age Distribution
          </h3>
          <ReactApexChart
            options={barChartData.options}
            series={barChartData.series}
            type="bar"
            height={300}
          />
        </div>
      </div>
    </div>
    </>
  );
}
