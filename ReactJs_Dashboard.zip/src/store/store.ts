
// store/store.ts
import { configureStore } from "@reduxjs/toolkit";
import budgetReducer from "../redux/budgetSlice";

export const store = configureStore({
  reducer: {
    budget: budgetReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
