// redux/budgetSlice.ts
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface Expense {
  id: number;
  name: string;
  amount: number;
}

interface BudgetState {
  totalBudget: number;
  expenses: Expense[];
}

const initialState: BudgetState = {
  totalBudget: 1000,
  expenses: [],
};

const budgetSlice = createSlice({
  name: "budget",
  initialState,
  reducers: {
    addExpense: (state, action: PayloadAction<Expense>) => {
      state.expenses.push(action.payload);
    },
    removeExpense: (state, action: PayloadAction<number>) => {
      state.expenses = state.expenses.filter(exp => exp.id !== action.payload);
    },
  },
});
export const { addExpense, removeExpense } = budgetSlice.actions;
export default budgetSlice.reducer;