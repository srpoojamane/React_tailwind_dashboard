import React from 'react';
import { useSelector, useDispatch } from "react-redux";
import { addExpense, removeExpense } from "../redux/budgetSlice";
import { useState } from "react";
import { RootState, AppDispatch } from "../store/store";
import ReactApexChart from 'react-apexcharts';

export default function BudgetTracker() {
  const { totalBudget, expenses } = useSelector((state: RootState) => state.budget);
  const dispatch: AppDispatch = useDispatch();
  const [expense, setExpense] = useState<{ name: string; amount: string }>({ name: "", amount: "" });

  const handleAddExpense = () => {
    if (expense.name && expense.amount) {
      dispatch(addExpense({ id: Date.now(), name: expense.name, amount: Number(expense.amount) }));
      setExpense({ name: "", amount: "" });
    }
  };

  // Example data for ads platforms
  const chartOptions = {
    chart: {
      type: 'bar', // Chart type: bar chart
      height: '400',
    },
    xaxis: {
      categories: ['Google Ads', 'Facebook Ads', 'LinkedIn Ads'], // Categories (Ad Platforms)
    },
    title: {
      text: 'Ad Platform Comparison',
      align: 'center',
      style: {
        fontSize: '16px',
        fontWeight: 'bold',
        color: '#333',
      }
    },
    plotOptions: {
      bar: {
        horizontal: false, // Make bars vertical
        columnWidth: '50%', // Column width
      },
    },
    legend: {
      position: 'top',
    },
  };

  // Data for the chart
  const chartSeries = [
    {
      name: 'Spend ($)',
      data: [5000, 3000, 2000], // Example spend data for each platform
    },
    {
      name: 'Clicks',
      data: [1000, 800, 600], // Example clicks data for each platform
    },
    {
      name: 'Conversions',
      data: [100, 120, 80], // Example conversions data for each platform
    },
  ];

  return (
    <div className="p-6 w-full max-w-lg mx-auto mt-6 bg-white shadow-lg rounded-lg">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Budget Tracker</h2>
      <p className="text-gray-600 mb-2 font-medium">Total Budget: <span className="text-gray-900 font-semibold">${totalBudget}</span></p>
      <p className="text-gray-600 mb-4 font-medium">Remaining: <span className="text-gray-900 font-semibold">${totalBudget - expenses.reduce((sum, e) => sum + e.amount, 0)}</span></p>
      
      <div className="flex gap-3 mb-4">
        <input
          type="text"
          placeholder="Expense Name"
          value={expense.name}
          onChange={(e) => setExpense({ ...expense, name: e.target.value })}
          className="border p-3 rounded-lg w-full focus:ring-2 focus:ring-blue-500"
        />
        <input
          type="number"
          placeholder="Amount"
          value={expense.amount}
          onChange={(e) => setExpense({ ...expense, amount: e.target.value })}
          className="border p-3 rounded-lg w-full focus:ring-2 focus:ring-blue-500"
        />
        <button
          onClick={handleAddExpense}
          className="px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          Add
        </button>
      </div>

      <div className="mt-6">
        {/* Render the ApexChart */}
        <ReactApexChart
          options={chartOptions}
          series={chartSeries}
          type="bar"
          height={400}
        />
      </div>

      <ul className="mt-4 divide-y divide-gray-200">
        {expenses.map((exp) => (
          <li key={exp.id} className="flex justify-between items-center py-3">
            <span className="text-gray-800 font-medium">{exp.name}: <span className="text-gray-900 font-semibold">${exp.amount}</span></span>
            <button
              onClick={() => dispatch(removeExpense(exp.id))}
              className="text-sm px-3 py-1 bg-red-500 text-white rounded-lg hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500"
            >
              X
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
