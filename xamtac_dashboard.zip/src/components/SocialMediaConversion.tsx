import React, { useState } from "react";

export default function SocialMediaConversion() {
  // Conversion rates for different platforms
  const [conversions, setConversions] = useState({
    googleAds: 75,
    facebookAds: 60,
    linkedinAds: 85,
    twitterAds: 50,
  });

  return (
    <div className="max-w-2xl mx-auto mt-10 p-6 bg-white shadow-lg rounded-lg">
      <h2 className="text-2xl font-bold text-gray-800 mb-4 text-center">
        Social Media Conversion Rates
      </h2>

      {/* Google Ads Progress Bar */}
      <div className="mb-4">
        <p className="text-lg font-medium text-gray-700">Google Ads</p>
        <div className="w-full bg-gray-200 rounded-full h-4">
          <div
            className="bg-blue-500 h-4 rounded-full transition-all duration-500"
            style={{ width: `${conversions.googleAds}%` }}
          ></div>
        </div>
        <p className="text-right text-sm font-semibold text-gray-700">{conversions.googleAds}%</p>
      </div>

      {/* Facebook Ads Progress Bar */}
      <div className="mb-4">
        <p className="text-lg font-medium text-gray-700">Facebook Ads</p>
        <div className="w-full bg-gray-200 rounded-full h-4">
          <div
            className="bg-green-500 h-4 rounded-full transition-all duration-500"
            style={{ width: `${conversions.facebookAds}%` }}
          ></div>
        </div>
        <p className="text-right text-sm font-semibold text-gray-700">{conversions.facebookAds}%</p>
      </div>

      {/* LinkedIn Ads Progress Bar */}
      <div className="mb-4">
        <p className="text-lg font-medium text-gray-700">LinkedIn Ads</p>
        <div className="w-full bg-gray-200 rounded-full h-4">
          <div
            className="bg-purple-500 h-4 rounded-full transition-all duration-500"
            style={{ width: `${conversions.linkedinAds}%` }}
          ></div>
        </div>
        <p className="text-right text-sm font-semibold text-gray-700">{conversions.linkedinAds}%</p>
      </div>

      {/* Twitter Ads Progress Bar */}
      <div className="mb-4">
        <p className="text-lg font-medium text-gray-700">Twitter Ads</p>
        <div className="w-full bg-gray-200 rounded-full h-4">
          <div
            className="bg-red-500 h-4 rounded-full transition-all duration-500"
            style={{ width: `${conversions.twitterAds}%` }}
          ></div>
        </div>
        <p className="text-right text-sm font-semibold text-gray-700">{conversions.twitterAds}%</p>
      </div>
    </div>
  );
}
