import { Package } from 'lucide-react';
import Breadcrumb from '../components/Breadcrumbs/Breadcrumb';
import Brands from '../components/Report/Brands';
import Packges from '../components/Report/Packages';
import Products from '../components/Report/Products';

const Tables = () => {
  return (
    <>
      <Breadcrumb pageName="Report Details" />

      <div className="flex flex-col gap-10">
        <Brands />
        <Packges />
        <Products />
      </div>
    </>
  );
};

export default Tables;
