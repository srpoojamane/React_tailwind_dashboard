const featureData = [
    { name: "CRM", icon: "fa fa-cogs", bg:"bg-blue-500" },
    { name: "Reports", icon: "fa fa-file-alt", bg: "bg-green-500" },
    { name: "Connect", icon: "fa fa-plug", bg: "bg-red-500" },
    { name: "Data Settings", icon: "fa fa-cogs", bg: "bg-yellow-500" },
    { name: "Site Health", icon: "fa fa-heartbeat", bg: "bg-purple-500" },
    { name: "Brand Monitoring", icon: "fa fa-bullhorn", bg: "bg-indigo-500" },
    { name: "Product", icon: "fa fa-box", bg: "bg-teal-500" },
    { name: "Orders", icon: "fa fa-box-open", bg: "bg-pink-500" },
  ];
  
  
  const Datas = () => {
    const Progress = ({ value }: { value: number }) => {
      return (
        <div className="w-full max-w-xs mx-auto mt-10 ">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Progress</span>
            <span className="text-xs font-medium">{value}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div
              className="bg-blue-600 h-2.5 rounded-full"
              style={{ width: `${value}%` }}
            ></div>
          </div>
        </div>
      );
    };
  
    return (
      <div className="flex w-full gap-6">
        {/* Left Grid Section */}
        <div className="grid grid-cols-3 gap-6 w-3/4 ">
        {featureData.map((item, index) => (
    <div key={index} className={`${item.bg} flex flex-col items-center p-6  rounded-lg shadow-md hover:shadow-lg transition`}>
      <i className={`${item.icon}  text-white text-4xl mb-3`} /> {/* Use FontAwesome class */}
      <p className="text-white font-medium">{item.name}</p>
    </div>
  ))}
        </div>
  
        {/* Right Sidebar Section */}
        <div className="w-1/4">
          <div className="bg-white p-4 rounded-lg shadow-md mb-4">
            <h3 className="text-lg font-semibold">Important</h3>
            <div className="bg-blue-500 text-white p-3 rounded-lg mt-2">
              <p className="font-semibold">Announcement</p>
              <p className="text-sm">Welcome to Xamtac. We are happy you are here!</p>
            </div>
          </div>
  
          <div className="bg-white p-4 rounded-lg shadow-md mb-4">
            <h3 className="text-md font-semibold">Company Info.</h3>
            <div className="flex items-center justify-between mt-2">
              <Progress value={20} />
              <span className="text-xs font-medium">20% Completed</span>
            </div>
            <a href="#" className="text-blue-500 text-sm mt-2 inline-block">
              Click here
            </a>
          </div>
  
          <div className="bg-white p-4 rounded-lg shadow-md">
            <h3 className="text-md font-semibold">Connect Reporting Data</h3>
            <p className="text-xs text-gray-600 mt-2">
              Sync with Google, Bing, and other platforms
            </p>
          </div>
        </div>
      </div>
    );
  };
  
  export default Datas;
  