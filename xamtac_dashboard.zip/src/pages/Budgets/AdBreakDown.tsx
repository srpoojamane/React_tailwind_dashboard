import React from "react";
import ReactApexChart from "react-apexcharts";

export default function AdBreakdown() {
  // Define data for the ring graph
  const chartData = {
    series: [40, 35, 25], // Sample data for Clicks, Cost, Conversions
    options: {
      chart: {
        type: "donut",
      },
      labels: ["Clicks", "Cost", "Conversions"],
      colors: ["#1E88E5", "#F44336", "#43A047"], // Blue, Red, Green
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 300,
            },
            legend: {
              position: "bottom",
            },
          },
        },
      ],
      legend: {
        position: "bottom",
      },
    },
  };

  return (
    <div className="max-w-3xl mx-auto p-6 bg-white shadow-lg rounded-lg mt-10">
      <h2 className="text-2xl font-bold text-gray-800 text-center mb-4">
        Ad Performance Breakdown
      </h2>

      {/* Ring Graph */}
      <div className="flex justify-center">
        <ReactApexChart
          options={chartData.options}
          series={chartData.series}
          type="donut"
          height={350}
        />
      </div>

      {/* Device Breakdown */}
      <div className="mt-6">
        <h3 className="text-xl font-semibold text-gray-800 text-center mb-3">
          Device Breakdown
        </h3>
        <div className="grid grid-cols-3 gap-4 text-center">
          {/* Mobile */}
          <div className="bg-blue-100 p-4 rounded-lg shadow">
            <p className="text-lg font-medium text-gray-700">📱 Mobile</p>
            <p className="text-xl font-bold text-blue-500">50%</p>
          </div>

          {/* Laptop */}
          <div className="bg-red-100 p-4 rounded-lg shadow">
            <p className="text-lg font-medium text-gray-700">💻 Laptop</p>
            <p className="text-xl font-bold text-red-500">30%</p>
          </div>

          {/* Tablets */}
          <div className="bg-green-100 p-4 rounded-lg shadow">
            <p className="text-lg font-medium text-gray-700">📟 Tablet</p>
            <p className="text-xl font-bold text-green-500">20%</p>
          </div>
        </div>
      </div>
    </div>
  );
}
