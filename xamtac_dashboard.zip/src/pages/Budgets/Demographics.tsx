import React from "react";
import ReactApexChart from "react-apexcharts";

export default function Demographics() {
  // Pie Chart Data (Gender Distribution)
  const pieChartData = {
    series: [45, 40, 15], // Male, Female, Undefined
    options: {
      chart: { type: "pie" },
      labels: ["Male", "Female", "Undefined"],
      colors: ["#1E88E5", "#E91E63", "#9E9E9E"], // Blue, Pink, Gray
      legend: { position: "bottom" },
    },
  };

  // Vertical Bar Chart Data (Age Group Distribution)
  const barChartData = {
    series: [
      {
        name: "Users",
        data: [35, 50, 30, 20], // Example age group data
      },
    ],
    options: {
      chart: { type: "bar" },
      xaxis: { categories: ["18-24", "25-34", "35-44", "45+"] },
      colors: ["#4CAF50"], // Green
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: "50%",
          borderRadius: 5,
        },
      },
    },
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white shadow-lg rounded-lg mt-10">
      <h2 className="text-2xl font-bold text-gray-800 text-center mb-4">
        Demographic Analytics
      </h2>

      <div className="grid grid-cols-2 gap-6">
        {/* Pie Chart (Gender Breakdown) */}
        <div className="bg-gray-100 p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-700 text-center mb-3">
            Gender Distribution
          </h3>
          <ReactApexChart
            options={pieChartData.options}
            series={pieChartData.series}
            type="pie"
            height={300}
          />
        </div>

        {/* Vertical Bar Chart (Age Breakdown) */}
        <div className="bg-gray-100 p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-700 text-center mb-3">
            Age Distribution
          </h3>
          <ReactApexChart
            options={barChartData.options}
            series={barChartData.series}
            type="bar"
            height={300}
          />
        </div>
      </div>
    </div>
  );
}
